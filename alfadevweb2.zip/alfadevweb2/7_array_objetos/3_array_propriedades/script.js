numero = [0,1,2,3,4,5,6];
nome=['joão', 'Marcos','Denicreidsson'];
booleanos=[true,false,true];

console.log(nome.length);

estudante = "caio";
console.log(estudante.length);

function teste($0, $1, $2, $3, $valor = null ){

}
console.log(teste.length);