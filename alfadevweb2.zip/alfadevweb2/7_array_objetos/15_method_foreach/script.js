nome = ["Bilu", "Pixu", "José", "Maria"]

nome.array.forEach(x => {
    console.log("Bons estudos " + x);
});