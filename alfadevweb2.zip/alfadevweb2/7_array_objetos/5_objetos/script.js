//objeto
cachorro = {
    //propriedades
    cor : "caramelo",
    patas : 4,
    nome: "cavalo",
    //metodo
    latir: function() {
        console.log("miau");
    }
}
cachorro.latir();
console.log(cachorro.patas);
console.log(cachorro.nome);
console.log(cachorro.cor);