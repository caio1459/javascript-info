marca = "nike";

console.log(marca.toUpperCase());

marca2 = marca.toUpperCase();

console.log(marca2.toLowerCase());