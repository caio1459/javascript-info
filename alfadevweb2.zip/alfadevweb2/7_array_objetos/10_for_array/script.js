
nomes = ["Juvi", "Bily", "Deny"]

for (let i = 0; i < nomes.length; i++) {
    console.log(nomes[i]);
}