pessoa = {
    nome: "Julie",
    idade: 12,
    profissao: "administrador"
}
console.log(pessoa.nome);
delete pessoa.nome;
console.log(pessoa.nome);
console.log(pessoa);
pessoa.casado = false;
console.log(pessoa.casado);

console.log(pessoa);