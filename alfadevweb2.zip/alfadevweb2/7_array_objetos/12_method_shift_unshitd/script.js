// adiciona e remove do inicio
nomes = ["Juvi", "Bily", "Deny"]

console.log(nomes.shift());

console.log(nomes);

console.log("izabelo", "rip");

console.log(nomes);