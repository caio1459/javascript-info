num = [0,1,2,3,4,5,6];

console.log(num.slice(2,5));
// tras a posiçao 4 para uma posiçao antes

console.log(num.slice(4));

console.log(num.slice(-2));
// tras a partir da posiçao

console.log(num.slice(1,-2));
// pega do 1 e deixa os dois ultimos