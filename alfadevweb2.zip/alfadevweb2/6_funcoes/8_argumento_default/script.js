function potencia(base,exp = 3){
    return Math.pow(base, exp);
}
console.log(potencia(2));
console.log(potencia(2,2));