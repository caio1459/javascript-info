escrever = () =>{
    console.log("Olá Mundo! ");
}
escrever();

soma = (a,b) =>{
    return a + b;
}
console.log(soma(10,20));
x = soma(10,10);
y = soma(20,10);
console.log(x + y);