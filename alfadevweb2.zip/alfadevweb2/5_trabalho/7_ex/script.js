/* 7_exercicio
Escreva um loop for que exibe 
números de um a um, indo de 200 
a 100 no console; 
    [inicializaçãoo] [condição]     [expressão]  */ 
for (let x = 200; x >= 100; x--) {
   console.log(x);
}