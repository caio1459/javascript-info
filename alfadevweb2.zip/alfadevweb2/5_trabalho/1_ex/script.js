/*1_exercicio
Cria uma estrutura de controle com if que verificará 
a entrada na em uma festa, se
tiver mais de 18 anos pode entrar;
Armazene a idade em uma variável;
Insira uma instrução mensagem (“Pode entrar”), 
caso a pessoa tenha mais que 18
anos;
*/ 
idade = 1;
if(idade >= 18){
    console.log('Pode Entrar');
}
