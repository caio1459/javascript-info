maior = Math.max(110,500,9,4,0,5);
console.log(maior);

menor = Math.min(110,500,9,4,0,5);
console.log(menor);

arredonda = Math.ceil(5.100);
console.log(arredonda);

aleatorio = Math.random();
console.log(aleatorio);