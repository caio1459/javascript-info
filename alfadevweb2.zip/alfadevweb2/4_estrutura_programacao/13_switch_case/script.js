nome = "Denicreidsson";
switch(nome){
    case "Denicreidsson": 
        console.log("Bem vindo Denicreidsson, tenho pena de você");
        break;
    case "João":
        console.log("Bem vindo João");
    break;
    default:
    console.log("Nome não encontrado!");
}